(function () {
  function initVibecheck(root) {
    if (!root || root.dataset.vibecheckInitialized === "true") return;

    root.dataset.vibecheckInitialized = "true";

    const modal = root.querySelector("[data-vibecheck-modal]");
    const openButton = root.querySelector("[data-vibecheck-open]");
    const closeButtons = root.querySelectorAll("[data-vibecheck-close]");
    const cameraButton = root.querySelector("[data-vibecheck-camera]");
    const uploadButton = root.querySelector("[data-vibecheck-upload]");
    const fileInput = root.querySelector("[data-vibecheck-file]");
    const preview = root.querySelector("[data-vibecheck-preview]");
    const video = root.querySelector("[data-vibecheck-video]");
    const image = root.querySelector("[data-vibecheck-image]");
    const status = root.querySelector("[data-vibecheck-status]");
    const backButton = root.querySelector("[data-vibecheck-back]");

    let cameraStream = null;

    function openModal() {
      modal.classList.add("is-open");
      modal.setAttribute("aria-hidden", "false");
      document.body.style.overflow = "hidden";
    }

    function stopCamera() {
      if (cameraStream) {
        cameraStream.getTracks().forEach(function (track) {
          track.stop();
        });

        cameraStream = null;
      }

      video.srcObject = null;
    }

    function closeModal() {
      stopCamera();

      modal.classList.remove("is-open");
      modal.setAttribute("aria-hidden", "true");

      document.body.style.overflow = "";

      resetPreview();
    }

    function resetPreview() {
      preview.hidden = true;
      video.hidden = true;
      image.hidden = true;

      image.removeAttribute("src");
      status.textContent = "";
    }

    async function startCamera() {
      openModal();

      try {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
          throw new Error("Camera API is not supported.");
        }

        status.textContent = "Requesting camera access...";

        cameraStream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: "user"
          },
          audio: false
        });

        video.srcObject = cameraStream;

        video.hidden = false;
        image.hidden = true;
        preview.hidden = false;

        status.textContent = "Camera ready. Position yourself in the frame.";
      } catch (error) {
        console.error("Vibecheck camera error:", error);

        status.textContent =
          "Camera access was blocked. Please allow camera permission and try again.";
      }
    }

    function openUpload() {
      openModal();

      fileInput.click();
    }

    function handleUpload(event) {
      const file = event.target.files && event.target.files[0];

      if (!file) return;

      if (!file.type.startsWith("image/")) {
        status.textContent = "Please select an image file.";
        return;
      }

      stopCamera();

      const imageUrl = URL.createObjectURL(file);

      image.src = imageUrl;

      image.hidden = false;
      video.hidden = true;
      preview.hidden = false;

      status.textContent =
        "Photo uploaded successfully. AI try-on processing will be connected next.";
    }

    function goBack() {
      stopCamera();

      resetPreview();

      status.textContent = "";

      fileInput.value = "";
    }

    openButton.addEventListener("click", openModal);

    closeButtons.forEach(function (button) {
      button.addEventListener("click", closeModal);
    });

    cameraButton.addEventListener("click", startCamera);

    uploadButton.addEventListener("click", openUpload);

    fileInput.addEventListener("change", handleUpload);

    backButton.addEventListener("click", goBack);

    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape" && modal.classList.contains("is-open")) {
        closeModal();
      }
    });
  }

  function initializeAll() {
    document.querySelectorAll("[data-vibecheck]").forEach(initVibecheck);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initializeAll);
  } else {
    initializeAll();
  }

  document.addEventListener("shopify:section:load", function (event) {
    const root = event.target.querySelector("[data-vibecheck]");

    if (root) {
      initVibecheck(root);
    }
  });
})();
